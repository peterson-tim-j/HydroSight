%% Groundwater Statistical Toolbox - _User Interface_

%% Overview
% The graphical user interface (GUI) for the Groundwater Statistical
% Toolbox provides an efficient means to build a wide range of groundwater
% time-series models without knowledge of Matlab programming or a copy of
% Matlab. It comprises of two independent modules:
%
% * Data Preparation: a data analysis and outlier detection
% module for detecting and removing erroneous water level observations
% prior to time-series modelling.
% * Time-series Modelling: a time-series modelling module for simulating
% hydrographs and, for example, decomposition of the hydrographs to drivers.
%
% To get started using the GUI, this page details the GUI system requirements,
% installation, data requirements and details of the key modelling steps.
%
% The GUI also has built in help. Aspects of this help are summarised below and shown within the following figure. 
% 
% * tool-tips are provided within most sections of the GUI. 
% * transfer function noise models (TFN) sub-functions show a summary pane describing the 
% function (see bottom-right of screenshot).
% * example TFN models can be loaded from the GUI menu.
%
% <<diagrams/doc_GUI.PNG>>
% 

%% System Requirements
% The system requirements to run the GUI as a stand alone application are:
%
% * Windows 64 bit operating system
% * At least 4GB RAM
% * Multiple CPU cores - this is required to reduce the model calibration time.

%% Installation
% To install the GUI as a stand alone application, run the installation
% program called _GroundwaterStatisticalToolkit_installed.exe_. If you are
% obtaining the program from the GitHub site, it is in 'Deployment' >
% 'Windowsx64' > 'TheGST' > 'for_redistribution'. Once installed, the 
% program can be started via your Windows 'Start' icon.

%% Data Requirements
% To get started modelling a groundwater hydrograph, the following data is
% required in .csv files:
%
% * observed groundwater head data with columns _bore ID_, _year_, _month_, _day_, _head_. Note, _hours_ and _minute_ can be included after _day_.
% * forcing data with columns _year_, _month_, _day_ and the columns for
% each forcing time series. Importantly, the first row must contain the column names (without spaces in names), the data must have a daily time-step and have no gaps
% and should extend prior to the first head observation.
% * projected coordinates for the bore ID and each forcing data with
% columns _Site ID_, _Easting_, _Northing_.
%
% Examples of the required data formats can be obtained from the inbuilt
% TFN model examples. Simply select an example model and input where the data files
% are to be saved. The saved .csv files can then be inpsected.

%% Getting Started
% 
% The modelling steps are defined by the following five tabs within the
% GUI. For data analysis and preparation, only step two is required.
% For time-series modelling, steps three and four are requires and five
% is optional.
%
% # <doc_GUI_projectDescription.html Project Description> : optional
% step to record the project title and description.
% # <doc_GUI_dataPrep.html Data Preparation>:  a data analysis and outlier detection
% module for detecting and removing erroneous water level observation.
% # <doc_GUI_ModelConstruct.html Model Construction>: the time-series module for inputting data and defining the model structure.
% # <doc_GUI_ModelCalib.html Model Calibration>: the time-series
% module for calibrating the constructed models.
% # <doc_GUI_ModelSimulate.html Model Simulation>: the time-series
% module to use a calibrated model for scenario investigations or hydrograph
% interpolation or extrapolation.

