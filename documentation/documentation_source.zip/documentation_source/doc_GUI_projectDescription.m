%% HydroSight - _Project Description GUI Tab_

%% Overview
% The _Project Description_ tab is the left most tab of HydroSight GUI. It is 
% an optional step and allows documentation of the modelling project. The user
% can input a title for the project and an extended description. There are
% no limitations on the format or length of these inputs. Below is a screen
% shot of the project description tab.
%
% <<diagrams/doc_GUI_projectDescription.png>>

%% Inputs
 % The following inputs are available:
 %
 % * _Project Title_ : A brief title for the project. There are no
 % limitations on the length or format.
 %
 % * _Project Description_: An extended description of the project. There
 % are no limitations on the format or length. However, a bug has been observed whereby, when new paragraphs
 % are created, the spacing between the paragraphs may increase each time
 % the description is displayed.

%% Outputs
% This tab creates no outputs.
