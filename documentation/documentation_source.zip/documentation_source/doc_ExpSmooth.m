%% Groundwater Statistical Toolbox - Exponential Smoothing Models

%% Overview
% This model simulates the head using a double exponential smoothing time-series model for irregular spaced  
% observations (Cipra et al. 2008). The double exponential smoothing undertakes a 
% smoothing of the trend in the head and exponential smoothing of the component of the 
% head not captured by the trend. Importantly, the trend is linear and is updated at each
% observation. Therefore, when the model is used for interpolation of the head the estimate
% has a discontinuity at each observation because of the updating of the trend.
% 
% In fitting the exponential model to an observed hydrograph, the exponential noise model
% from Peterson & Western (2014) was added. This provides a weighted least squares 
% objective function and hence a means for minimisation all three of the model parameters.
% 
% In using the model, it does not use any forcing data, such as rainfall or extraction rate.
% However, the toolkit user interface does require all models to have forcing data and 
% coordinate data. Therefore, in using this model, forcing and coordinate data files must be
% input but the files can contain junk data, e.g. all rainfall days can be zero. 
% 
% Lastly, there are no user options for constructing this model.
%

%% References
%
% * Peterson, T. J. and Western A. W. (2014). Nonlinear time-series modeling of unconfined groundwater head. _Water Resources Research_, 50, 8330–8355, DOI: <http://dx.doi.org/10.1002/2013WR014800 10.1002/2013WR014800>. <papers/Peterson_Western_2014.pdf PDF Copy>
% * Cipra T. and Hanzák T. (2008). Exponential smoothing for irregular time series. _Kybernetika_,  44(3), 385-399.
