%% HydroSight - _Disclaimer and Licenses_

%% Disclaimer
%
% HydroSight is provided on an "as is" basis and without any representation 
% as to functionality, performance, suitability or fitness for purpose.  
% You acknowledge and agree that, to the extent permitted under law, and 
% subject to Disclaimers, the University of Melbourne makes no representations, 
% warranties or guarantees:
%
% # in relation to the functionality, performance, availability, suitability, 
% continuity, reliability, accuracy, currency or security of the Program; or
% # that the Program is free from computer viruses or any other defect or 
% error which may affect Your program or systems or third party software or systems. 
%
% You further acknowledge and agree that the University of Melbourne has no obligation
% to (and makes no representation that it will) maintain or update, or correct any errors 
% or defects in, the Program
%

%% License
% 
% HydroSight toolkit is licensed under the
% open-source license GPL3.0 (or later). See the following for details: <http://www.gnu.org/licenses/gpl-3.0.en.html>

%% Externally Licensed Components
%
% The following components of the HydroSight were developed by
% others and companent each has its own license. These components and their licence are within the
% source code folder: _algorithms_ > _calibration_.
%
% * _cmaes.m_ calibration algorithm.
% * _DREAM.m_ as supporting files for probablistic calibration.
% * _GUI Layout Toolbox 2.1_ for constructing the panels of the GUI
% * _ipdm.m_ for calculating the inter-point distance used in HydroSight temporal kriging.
% * _SPUCI.m_ calibration algorithm and its associated functions.
% * _uical.m_ for displaying a graphical calendar within the GUI.
% * _variogram.m_, _variogramfit.m_ and _fminsearchbnd.m_ for estimating and fitting
% variograms.


