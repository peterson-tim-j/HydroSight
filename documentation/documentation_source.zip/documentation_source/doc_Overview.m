%% HydroSight
% _A toolbox for data-driven hydrogeological insights._ 

%% Overview
% HydroSight is a highly flexible statistical toolbox and user 
% interface for getting more quantitative value from groundwater
% level monitoring data.  Currently, the toolbox contains a highly flexible groundwater
% hydrograph time-series modeling framework (Peterson and Western, 2014) that facilitates the following:
% 
% * decomposition of a groundwater hydrograph into individual drivers, such as climate
% and pumping or climate (Shapoori et al. 2015a) and landuse change (Peterson and Western, 2014).
% * estimation of aquifer hydraulic properties from the hydrograph (Shapoori et al. 2015b)
% * statistical identification of the major groundwater processes (Shapoori et al. 2015a).
% * interpolation or extrapolation of the observed hydrograph.
% * simulation of groundwater head under different climate or, say, pumping scenarios.
% * numerical identification of hydrograph monitoring errors and outliers.
%
% HydroSight can be used in two ways:
%
% * <doc_Programmatically.html Programmatically> : using a 
% collection Matlab of object-oriented classes that provides enormous flexibility
% to built time-series models and develop new models and components.
% * <doc_GUI.html Graphical User Interface> : stand alone
% application that provides a highly flexible framework for the efficient construction, 
% modelling and simulation of an unlimited number of models within a simple
% graphical environment. 
%
% To get started with HydroSight, click on the link above for the way in which
% you'd like to use HydroSight. Each link provides details of how to install the
% software, system requirements and how to get started building models.
%
% For further details on the the fundementals, the project, obtaining code or reporting bugs
% please see the sections below. 

%% Modelling Fundamentals
% HydroSight allows for different types of time-series models to be built.
% Below is a summary of the key types of models:
%
% * <doc_TFN.html Transfer Function Noise (TFN) models>: weight one or multiple time series of
% forcing data, such as rainfall or pumping, to simulate the observed
% hydrograph. This is the recommended model for most applications. 
% * <doc_ExpSmooth.html Exponential Smoothing models>: use a double
% exponential smoothing filter to simulate the smoothed trend of observed the
% hydrograph and does so without using observed forcing data.
%
% Data requirements for the models differ. While both can use irregularly
% spaced observed hydrograph head observations, the TFN model requires
% daily observed forcing data and as a minimum it should use daily rainfall
% and potential evapotranspiration. 
%
% Once the model has been constructed for a given bore, the parameters of
% the model must be calibrated; that is, adjusted to achieve a minimum
% error between the observed and modelled hydrograph. This is achieved
% by reducing the difference between the observed and modelled hydrograph
% to a single number, called an objective function value, which is this
% case is effectively the weighted least squares. To minimise this objective
% function value, HydroSight includes global calibration schemes (see <doc_Calibration.html here> for details).
% This can be very computationally demanding and it is always uncertain if
% the very best solution (i.e. the global optima) has been located. For
% tips on how to best undertake the calibration see the above link.

%% Collaborations and Consulation Services
% Some groundwater statistical problems can be particularly challenging to 
% investigate using HydroSight, or it may not contain
% the features you require. If so, consider contacting Dr. Tim Peterson
% (timjp@unimelb.edu.au) to discuss collaboration or consultation options.
 
%% Reporting Bugs and Issues
% Bugs and problems with HydroSight can be reported at <https://github.com/peterson-tim-j/HydroSight/issues>.
% In reporting an issue please provide as much detail and data as possible to
% allow the bug or issue to be reproduced. 

%% Source Code
% The source code is available from GitHub at
% <https://github.com/peterson-tim-j/HydroSight>. If you would like to contribute to the project or add components, please join the project at GitHub.

%% The Developers
% HydroSight has been developed by the following academics at the University of Melbourne:
%
% * Tim Peterson
% * Andrew Western
% * Eleanor Gee
% * Vahid Shapoori
%
% To find out more about the research within the group, or relevant publications, see:
%
% * Research group: <http://www.ie.eng.unimelb.edu.au/research/water/index.html>
% * Research Gate : <https://www.researchgate.net/profile/Tim_Peterson7>
% * Google Scholar: <http://scholar.google.com.au/citations?user=kkYJLF4AAAAJ&hl=en&oi=ao> 
%
% Alternatively, to stay connected with developments and new versions join us at LinkedIn:
%
% * LinkedIn: <https://au.linkedin.com/pub/tim-peterson/81/40/739>
% 

%% Acknowledgements
% HydroSight has been generously supported by the following organisations:
%
% * The Australian Research Council grants LP0991280, LP130100958.
% * The Bureau of Meteorology (Aust.)
% * The Department of Environment, Land, Water and Planning (Vic., Aust.)
% * The Department of Economic Development, Jobs, Transport and Resources (Vic., Aus.)
% * Power and Water Corporation (N. T., Aus.)

%% License and Disclaimer
% HydroSight is licensed under the
% open-source license GPL3.0 (or later). See <doc_License_Disclaimer.html here> for 
% details of the disclaimer and licenses.
%

%% References
%
% * Peterson, T. J., and A. W. Western (2014). Nonlinear time-series modeling of unconfined groundwater head.  _Water
% Resources Research_, 50, 8330-8355, DOI: <http://dx.doi.org/10.1002/2013WR014800 10.1002/2013WR014800>. <papers/Peterson_Western_2014.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (2015).
% Top-down groundwater hydrograph time-series modeling for climate-pumping
% decomposition, _Hydrogeology Journal_, 23(4), 819-83, DOI: <http://dx.doi.org/10.1007/s10040-014-1223-0 10.1007/s10040-014-1223-0>. <papers/Shapoori_2015B.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F.
% (accepted). Estimating aquifer properties using groundwater hydrograph
% modeling. _Hydrological Processes_, Accepted June 2015, DOI:
% <http://dx.doi.org/10.1002/hyp.10583 10.1002/hyp.10583>. <papers/Shapoori_2015C.pdf PDF Copy>
