%% HydroSight - Publications

%% Overview
% The following papers on HydroSight are available within the GUI:
%
% * Peterson, T. J. and Western A. W. (2014). Nonlinear time-series modeling of unconfined groundwater head. _Water Resources Research_, 50, 8330-8355, DOI: <http://dx.doi.org/10.1002/2013WR014800 10.1002/2013WR014800>. <papers/Peterson_Western_2014.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (accepted). Estimating aquifer properties using groundwater hydrograph
% modeling. _Hydrological Processes_, Accepted June 2015, DOI: <http://dx.doi.org/10.1002/hyp.10583 10.1002/hyp.10583>. <papers/Shapoori_2015C.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (2015a). Decomposing groundwater head variations into meteorological and pumping components: a synthetic study, _Hydrogeology Journal_, DOI: <http://dx.doi.org/10.1007/s10040-015-1269-7 10.1007/s10040-015-1269-7>. <papers/Shapoori_2015A.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (2015b). Top-down groundwater hydrograph time-series modeling for climate-pumping decomposition, _Hydrogeology Journal_, 23(4), 819-83, DOI: <http://dx.doi.org/10.1007/s10040-014-1223-0 10.1007/s10040-014-1223-0>. <papers/Shapoori_2015B.pdf PDF Copy>