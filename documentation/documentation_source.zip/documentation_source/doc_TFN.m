%% Groundwater Statistical Toolbox - Transfer Function Noise Models

%% Overview
% The transfer function noise model (TFN) simulates an observed hydrograph
% by weighting the historic input forcing data, such as rainfall or groundwater pumping, 
% and estimating the random noise as an exponential decay
% function, which allows irregular water level observations to be
% simulated (von Asmuth et al., 2005). That is, for each water level
% observation the entire historic daily forcing data is obtained and a
% weight is applied to each day's past forcing data. This weighted forcing is
% then integrated over time (i.e. summed) to give the contribution of the historic forcing to
% the water level at the time point of interest. This is then repeated for every water level
% observation. Importantly, the weights are not uniform back in time but
% are defined by a simple function and can have, say, a decayed exponential 
% distribution, a Guassian-like skewed distribution or a distribution derived from 
% the Theis drawdown equation. In applying the TFN
% model, the parameters for the weighting functions are adjusted using a <doc_Calibration.html global
% calibration scheme> (Peterson and Western, 2014).
% 
% A weakness of simply weighting past rainfall is, however, that the
% nonlinear partitioning of rainfall is not accounted for. This is
% addressed within the Toolbox by the ability to transform forcing data
% prior to the weighting (Peterson and Western 2015). For example, a simple 
% 1-D vertically lumped soil model can be included in the time-series 
% modelling and calibrated to account for the often nonlinear response of
% the water table to rainfall.
%
% Lastly, the model TFN time-series model can also be calibrated
% using Xeon Phi co-processor cards. If a co-processor card is available 
% then the numerical intergration step of the TFN model will be
% undertaken using the co-processor card(s). To use this features, the
% computer requires Intel compiler ICC >=2013.

%% Weighting Function Components
%
% The toolkit allows the user to select one of the following weighting
% functions for each forcing data time series:
%
% * _responseFunction_Bruggeman_ : used for simulating the streamflow influence on head (von Asmuth et al. 2008). 
% Note, this function is still to be tested and must be used with caution.
% * _responseFunction_FerrisKnowles_ : used for simulating the drawdown
% from pumping with an instantaneous version for the Theis drawdown equation (Shapoori et al.
% 2015a, 2015b).
% * _responseFunction_FerrisKnowlesJacobs_ : as for _responseFunction_FerrisKnowles_ but 
% with Jacob's correction added to approximate an unconfined aquifer (Shapoori et al. 2015b).
% * _responseFunction_Hantush_ : used for simulating drawdown from pumping
% assuming a leaky aquifer response (Shapoori et al. 2015a).
% * _responseFunction_Pearsons_ : used for simulating climatic influences
% that increase the head, for example recharge  (Peterson and Western
% 2014).
% * _responseFunction_PearsonsNegative_ : as for _responseFunction_Pearsons_ but with a 
% sign change to simulate climatic influences
% that lower the head, for example ET (Peterson and Western 2014).
%
% The above weighting functions can also be used as inputs to the following
% derived weighting functions. This allow, for example, the impact from ET to be
% simulated not as an additional weighting function but by simply
% re-scaling the Pearson's weighting function used for recharge, and hence
% eliminating two model parameters from the model.
%
% * _derivedweighting_UnconstrainedRescaled_ : rescales an input weighting
% function whereby the recsaling can be positive or negative. This
% function can be used to simulate the impacts of, say, revegetation by
% rescaling _responseFunction_Pearsons_ used to simulate recharge.
% For details, see the GUI example _TFN model - Landuse change_.
% * _derivedweighting_PearsonsNegativeRescaled_ : similar to
% _derivedweighting_UnconstrainedRescaled_ but only to be used to rescale
% _responseFunction_Pearsons_. The function uses a normalised Pearson's
% function and then applies a scaling parameter. This may reduce the
% parameter covariance between the input weighting function and the
% rescaling and hence contribute to reliable calibration.
% * _derivedweighting_PearsonsPositiveRescaled_ : as for
% _responseFunction_Pearsons_ but using a negative rescaling.

%% Forcing Transform Components
%
% The toolkit allows the user to select the following forcing transformation function:
%
% * _climateTransform_soilMoistureModels_ : is a generalised vertically lumped 1-D
%   soil moisture model. It is used to transform daily climate data
%   for use in the transfer noise function groundwater time-series model.  
%   The soil moisture model is defined by the following ordinary
%   differential equation (Kavetski et al. 2006) and the following soil
%   fluxes/data can be used in the time-series modelling. See Peterson and
%   Western (2014) for details and recommendations on the form of the soil
%   model to adopt.
% * _climateTransform_soilMoistureModels_2layer_ : is identifcal to the
%   above one layer model but has a second deeper soil store whereby the
%   free-drainage from the upper store drains into the deeper store; and ET
%   does not occur from the deeper store.
%
% <html>
% <table border=1>
% <tr><td>Soil Model Flux/Data</td><td>Description</td></tr>
% <tr><td>Drainage</td><td>soil free drainage ranging (0 to k_sat) at the end of the day.</td></tr>
% <tr><td>Drainage bypass flow</td><td>Free drainage plus a parameter set fraction of runoff.</td></tr>
% <tr><td>Drainage normalised </td><td>Normalised free drainage (0 to 1) at the end of the day.</td></tr>
% <tr><td>Soil evaporation</td><td>Estimated soil ET at the end of the day.</td></tr>
% <tr><td>Infiltration</td><td>Daily total infiltration rate.</td></tr>
% <tr><td>Groundwater evaporative potential</td><td>Groundwater evaporative potential (PET - soil ET).</td></tr>
% <tr><td>Runoff</td><td>Total daily runoff.</td></tr>
% <tr><td>SMS</td><td>soil moisture storage at the end of each day.</td></tr>
% </table>
% </html>
%
% $\frac{dS}{dt} = P_{inf} (1 - \frac{S}{SMSC})^\alpha - k_{sat} (\frac{S}{SMSC})^\beta - PET (\frac{S}{SMSC})^\gamma$
%
%
% The soil moisture model can also be used to simulate the impacts from
% different vegetation; for example, trees and pastures. This is achieved
% by simulating a soil store for upto two land types and then weighting
% required flux from each soil model by an input time series of the
% fraction of the second land type. A challange with the input time series 
% of land cover is, however, that while the fraction of, say, land
% data clearing over time may be known the fraction of the catchment area
% cleared that influences a bore hydrograph is unknown. To address this,
% the modelling also include a parameter 'treeArea_frac' for the fraction
% of the second land cover (notially trees) that is influencing the bore.
%   
% An alternative approach for simulating the impacts of land cover change is 
% to use the forcing transformation functions as inputs to the following
% derived transformation functions. This allow, for example, the impact of
% revegetation to be simulated by creating a new flux from the soil
% moisture model that is scaled by the fraction of revegetation. That is,
% the free drainage from the soil moisture model could be scaled by a time
% series of the fraction of revegetation to produce an estimate of the
% change in recharge from the revegetation. For details, see the GUI example _TFN model - Landuse change_.
%
% * _derivedForcing_linearUnconstrainedScaling_ : rescales a
% transformation function flux whereby the rescaling can be positive or
% negative. Additionally, in the calibration the rescaling is initially
% assumed to be +- 0.2 of the transformation function flux. 

%% References
%
% * von Asmuth, J. R. and Bierkens M. F. P.  (2005). Modeling irregularly spaced residual series as a continuous stochastic process, _Water Resources Research_, 41, W12404, DOI: <http://dx.doi.org/10.1029/2004WR003726 10.1029/2004WR003726>.
% * von Asmuth J. R., Mass K., Bakker M., Peterson J., (2008). Modeling time series of ground water head fluctuations subject to multiple
% stresses. _Groundwater_, 46(1), 30-40. DOI: <http://dx.doi.org/10.1111/j.1745-6584.2007.00382.x 10.1111/j.1745-6584.2007.00382.x>
% * Kavetski, D., G. Kuczera, and S. W. Franks (2006), Bayesian analysis of input uncertainty in hydrological modeling: 1. Theory, _Water Resources Research_, 42, W03407, DOI: <http://dx.doi.org/10.1029/2005WR004368 10.1029/2005WR004368>. 
% * Peterson, T. J. and Western A. W. (2014). Nonlinear time-series modeling of unconfined groundwater head. _Water Resources Research_, 50, 8330-8355, DOI: <http://dx.doi.org/10.1002/2013WR014800 10.1002/2013WR014800>. <papers/Peterson_Western_2014.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (2015a). Decomposing groundwater head variations into meteorological and pumping components: a synthetic study, _Hydrogeology Journal_, DOI: <http://dx.doi.org/10.1007/s10040-015-1269-7 10.1007/s10040-015-1269-7>. <papers/Shapoori_2015A.pdf PDF Copy>
% * Shapoori V., Peterson T.J. , Western A.W. and Costelloe J. F. (2015b). Top-down groundwater hydrograph time-series modeling for climate-pumping decomposition, _Hydrogeology Journal_, 23(4), 819-83, DOI: <http://dx.doi.org/10.1007/s10040-014-1223-0 10.1007/s10040-014-1223-0>. <papers/Shapoori_2015B.pdf PDF Copy>