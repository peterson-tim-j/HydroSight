%% HydroSight - Programmatic Modelling

%% Overview
% HydroSight can be ran from the command line from within
% Matlab. This allows considerable flexibility in how models are developed
% and allows much of the analysis to be done using Matlab scripts. The
% toolkit is also written using object-oriented programming and this allows
% models to be easily built and incorporated into the toolkit. To view the
% code documentation, change the Matlab working directory to where the source code was downloaded and 
% run the following Matlab commands:
%
%%
cd algorithms
addpath(genpath(pwd))
doc HydroSightModel

%% System Requirements
% The system requirements to run the Toolkit programmatically are:
%
% * Matlab 2014B or later with the Statistics Toolbox
% * At least 4GB RAM
% * Multiple CPU cores - this is required to reduce the model calibration time.

%% Installation
% To install the programmatic version of the toolbox:
%
% # download the source code (see <doc_Overview.html#5 Overview>)
% # Open Matlab and change the Current Folder to the location where the
% source code was saved.
% # Add the current folder and all sub-folders to the Matlab search path. 
% # The algorithms are within the folder _algorithms_. To run the toolbox
% GUI, enter the command:
%%
HydroSight

%% Data Requirements
% To get started modelling a groundwater hydrograph, the following data is
% required:
%
% * observed groundwater head data (as a numerical matrix) with columns _bore ID_, _year_, _month_, _day_, _head_. Note, _hours_ and _minute_ can be included after _day_.
% * forcing data (as a Matlab table variable) with columns _year_, _month_, _day_ and the columns for
% each forcing time series. Importantly, the table must include the column names (without spaces in names), the data must have a daily time-step and have no gaps
% and should extend prior to the first head observation.
% * projected coordinates (as a cell array or table variable) for the bore ID and each forcing data with
% columns _Site ID_, _Easting_, _Northing_.
%
% Examples of the required data formats can be obtained from the example TFN
% model at _algorithms_ > _models_ > _TransferNoise_ >
% _Example model_.